package com.exam.sample.entity;

public class User3 {
	
	//필수항목
	private String userid;
	private String passwd;
	
	//옵션항목
	private String email;
	private String address;
	private String phone;
	
	// 중첩 클래스
	public static class Builder{
		
		//필수항목
		private String userid;
		private String passwd;
		
		//옵션항목
		private String email="";
		private String address="";
		private String phone="";
		
		//필수 항목 생성자
		public Builder(String userid, String passwd) {
			this.userid = userid;
			this.passwd = passwd;
		}
		
		//옵션 항목 설정 메서드
		public Builder email(String email) {
			this.email = email;
			return this;   // .(dot)로 체인 사용 가능
		}
		public Builder address(String address) {
			this.address = address;
			return this;   // .(dot)로 체인 사용 가능
		}
		public Builder phone(String phone) {
			this.phone = phone;
			return this;   // .(dot)로 체인 사용 가능
		}
		
		public User3 build() {
			return new User3(this);
		}

	}//end Builder

	public User3(Builder builder) {
		this.userid = builder.userid;
		this.passwd = builder.passwd;
		this.email = builder.email;
		this.address = builder.address;
		this.phone = builder.phone;
	}

	//getter 만 사용
	public String getUserid() {
		return userid;
	}

	public String getPasswd() {
		return passwd;
	}

	public String getEmail() {
		return email;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}
	
}//end User3







