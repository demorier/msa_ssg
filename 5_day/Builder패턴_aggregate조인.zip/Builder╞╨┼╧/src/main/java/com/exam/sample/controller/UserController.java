package com.exam.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.entity.User1;
import com.exam.sample.entity.User2;
import com.exam.sample.entity.User3;
import com.exam.sample.entity.User4;
import com.exam.sample.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService service;

	// 1. 점층적 생성자 패턴
	@GetMapping("/user1")
	public User1 hello() {
		User1 xxx = service.findByUser();
		return xxx;
	}

	// 2. 자바 빈 패턴
	@GetMapping("/user2")
	public User2 hello2() {
		return service.findByUser2();
	}

	// 3. Builder 패턴
	@GetMapping("/user3")
	public User3 hello3() {
		return service.findByUser3();
	}

	// 4. Builder 패턴 + lombok
	@GetMapping("/user4")
	public User4 hello4() {
		return service.findByUser4();
	}
}
