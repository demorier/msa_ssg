package com.exam.sample.entity;

public class User1 {
	
	//필수항목
	private String userid;
	private String passwd;
	
	//옵션항목
	private String email;
	private String address;
	private String phone;
	
	// #####################오버로딩 생성자###################################
	public User1() {}
	
	public User1(String userid, String passwd, String email, String address, String phone) {
		this.userid = userid;
		this.passwd = passwd;
		this.email = email;
		this.address = address;
		this.phone = phone;
	}

	public User1(String userid, String passwd, String email, String address) {
		this(userid, passwd, email, address, "phone");
	}
	// #####################오버로딩 생성자###################################
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "User1 [userid=" + userid + ", passwd=" + passwd + ", email=" + email + ", address=" + address
				+ ", phone=" + phone + "]";
	}

}
