package com.exam.sample.service;

import org.springframework.stereotype.Service;

import com.exam.sample.entity.User1;
import com.exam.sample.entity.User2;
import com.exam.sample.entity.User3;
import com.exam.sample.entity.User4;

@Service
public class UserService {

	// 1. 점층적 생성자 패턴
	/*
	 * ==> 여러  생성자를 이용하여 생성한다.
	 * 
	 * 가. 생성자의 인자수 많을 때는 의미를 알기가 어렵다. 
	 * 나. 많은 수의 오버로딩 생성자가 필요하다.
	 * 다. 필수 항목에 대한 인지가 어렵다.
	 */
	public User1 findByUser() {
		User1 user =
				new User1("userid", "passwd", "email", "address", "phone");
		return user;
	}
	

	// 2. 자바빈 패턴
	/*
	 *  ==>  생성자가 아닌 setter 메서드를 이용해서 생성한다.
	 *  
	 *  가. 각 인자의 의미 파악이 쉬워졌다.
	 *  나. 1회 호출로 객체 생성이 끝나지 않는다.
	 *  다. setter 메서드가 있기 때문에 변경 불가능(immutable) 클래스를 만들 수 없다.
	 *  라. 필수 항목에 대한 인지가 어렵다.
	 */
	public User2 findByUser2() {
		User2 user = new User2();
		user.setUserid("userid");
		user.setPasswd("passwd");
		user.setEmail("email");
		user.setAddress("address");
		user.setPhone("phone");
		return user;
	}

	//3. Builder 패턴
	/*
	 *  가. 각 인자가 어떤 의미인지 알 수 있다.
	 *  나. setter 메서드가 없기 때문에 immutable 객체 생성 가능
	 *  다. 한번에 객체 생성이 가능하다. (메서드 체인 활용)
	 */
	public User3 findByUser3() {
		User3.Builder builder = new User3.Builder("userid", "passwd");
		builder.email("email");
		builder.address("address");
		builder.phone("phone");
		return builder.build();
	
	}
	// (****)
	public User3 findByUser3_1() {
		User3 user3 = new User3.Builder("userid", "passwd")
										.email("email")
										.address("address")
										.phone("phone")
										.build();
		return user3;
	}
	//4. Builder 패턴 + lombok
	public User4 findByUser4() {
		User4 user = User4.builder()
						  .userid("userid")
						  .passwd("passwd")
						  .email("email")
						  .address("address")
						  .phone("phone")
						  .build();
		return user;
	}

}
