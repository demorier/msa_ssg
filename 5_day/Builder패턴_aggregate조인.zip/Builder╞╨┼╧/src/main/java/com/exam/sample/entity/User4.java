package com.exam.sample.entity;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class User4 {
	
	//필수항목
	private String userid;
	private String passwd;
	
	//옵션항목
	private String email;
	private String address;
	private String phone;
	
	@Override
	public String toString() {
		return "User4 [userid=" + userid + ", passwd=" + passwd + ", email=" + email + ", address=" + address
				+ ", phone=" + phone + "]";
	}

}
