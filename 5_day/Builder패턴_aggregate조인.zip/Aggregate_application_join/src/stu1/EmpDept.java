package stu1;

public class EmpDept {

	private String empId;
	private String ename;
	private int salary;
	private String departNo;  // 부서 참조
	private String dname;
	private String loc;
	
	
	public EmpDept() {
		super();
	}

	public EmpDept(String empId, String ename, int salary, String departNo, String dname, String loc) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.salary = salary;
		this.departNo = departNo;
		this.dname = dname;
		this.loc = loc;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDepartNo() {
		return departNo;
	}

	public void setDepartNo(String departNo) {
		this.departNo = departNo;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "EmpDept [empId=" + empId + ", ename=" + ename + ", salary=" + salary + ", departNo=" + departNo
				+ ", dname=" + dname + ", loc=" + loc + "]";
	}

}
