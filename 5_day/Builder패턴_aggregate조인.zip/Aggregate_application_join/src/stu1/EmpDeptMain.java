package stu1;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class EmpDeptMain {

	public static void main(String[] args) {

		List<Emp> empList = Arrays.asList(
				new Emp("A01", "홍길동", 1000, "D01"),
				new Emp("B01", "이순신", 2000, "D02"),
				new Emp("C01", "유관순", 1500, "D02"),
				new Emp("D01", "강감찬", 3000, "D03"));
		
		
		List<Dept> deptList = Arrays.asList(
				new Dept("D01", "관리", "서울"),
				new Dept("D02", "개발", "경기"),
				new Dept("D03", "인사", "제주"));
		
		
		// Application 조인 패턴
		/*
		    1. join 대상인 master List를 Map으로 변경한다. (Stream 의 toMap 이용)
			2. 메인 List 를 stream 으로 돌면서 map 을 통해 신규 객체에 값을 set 하고 조인대상 map 에 
			   containsKey로 Key가 있다면 해당 map의 value 를 set 한다.
			3. 최종 dto 들은 List 로 묶어 전달한다.

		 */
		
		Map<String, Dept> map = 
				deptList.stream().collect(Collectors.toMap(d->d.getDeptNo(), d -> d));
		
		
		List<EmpDept> list = empList.stream()
				                    .map(e->{
				                    	EmpDept all = new EmpDept();
				                    	all.setEmpId(e.getEmpId());
				                    	all.setEname(e.getEname());
				                    	all.setSalary(e.getSalary());
				                    	all.setDepartNo(e.getDepartNo());
				                    	
				                    	if(map.containsKey(e.getDepartNo())) { 
				                    		all.setDname(map.get(e.getDepartNo()).getDname());
				                    		all.setLoc(map.get(e.getDepartNo()).getLoc());
				                    	}
				                    	return all;
				                    })
				                    .collect(Collectors.toList());
		for(EmpDept xx : list) {
		   System.out.println(xx);
		}
	}

}
