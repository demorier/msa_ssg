package stu2;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class EmpDeptLocMain {

	public static void main(String[] args) {

		List<Emp> empList = Arrays.asList(
				new Emp("A01", "홍길동", 1000, "D01"),
				new Emp("B01", "이순신", 2000, "D02"),
				new Emp("C01", "유관순", 1500, "D02"),
				new Emp("D01", "강감찬", 3000, "D03"));
		
		
		List<Dept> deptList = Arrays.asList(
				new Dept("D01", "관리", "L01"),
				new Dept("D02", "개발", "L02"),
				new Dept("D03", "인사", "L02"));
		
		
		List<Location> locList = Arrays.asList(
				new Location("L01", "서울"),
				new Location("L02", "경기"),
				new Location("L03", "제주"));
		
		
		// aggregate application join
		
		Map<String, Location> locMap = 
				locList.stream().collect(Collectors.toMap(d->d.getLocNo(), d -> d));
		
		Map<String, Dept> dMap = 
				deptList.stream().collect(Collectors.toMap(d->d.getDeptNo(), d -> d));
		
		
		List<EmpDeptLoc> list = empList.stream()
                .map(e->{
                	EmpDeptLoc all = new EmpDeptLoc();
                	all.setEmpId(e.getEmpId());
                	all.setEname(e.getEname());
                	all.setSalary(e.getSalary());
                	all.setDepartNo(e.getDepartNo());
                	
                	if(dMap.containsKey(e.getDepartNo())) { 
                		all.setDname(dMap.get(e.getDepartNo()).getDname());
                		String locNO = dMap.get(e.getDepartNo()).getLocNo();
                		if(locMap.containsKey(locNO)){
                			all.setLocNo(locNO);
                			all.setCity(locMap.get(locNO).getCity());
                		}
                	}
                	return all;
                })
                .collect(Collectors.toList());
		
		for(EmpDeptLoc xx : list) {
			   System.out.println(xx);
		}
		
	}//end main
}//end class









