package stu2;


//부서 정보
public class Dept {

	private String deptNo;  
	private String dname;
	private String locNo;  // 위치 참조
	
	public Dept() {}

	public Dept(String deptNo, String dname, String locNo) {
		super();
		this.deptNo = deptNo;
		this.dname = dname;
		this.locNo = locNo;
	}

	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLocNo() {
		return locNo;
	}

	public void setLocNo(String locNo) {
		this.locNo = locNo;
	}

	@Override
	public String toString() {
		return "Dept [deptNo=" + deptNo + ", dname=" + dname + ", locNo=" + locNo + "]";
	}

}
