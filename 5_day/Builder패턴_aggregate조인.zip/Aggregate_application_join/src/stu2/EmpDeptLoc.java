package stu2;

public class EmpDeptLoc {

	private String empId;
	private String ename;
	private int salary;
	private String departNo;  // 부서 참조
	private String dname;
	
	private String locNo;
	private String city;
	
	public EmpDeptLoc() {
	}

	public EmpDeptLoc(String empId, String ename, int salary, String departNo, String dname, String locNo,
			String city) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.salary = salary;
		this.departNo = departNo;
		this.dname = dname;
		this.locNo = locNo;
		this.city = city;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDepartNo() {
		return departNo;
	}

	public void setDepartNo(String departNo) {
		this.departNo = departNo;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLocNo() {
		return locNo;
	}

	public void setLocNo(String locNo) {
		this.locNo = locNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "EmpDeptLoc [empId=" + empId + ", ename=" + ename + ", salary=" + salary + ", departNo=" + departNo
				+ ", dname=" + dname + ", locNo=" + locNo + ", city=" + city + "]";
	}

}
