package stu2;

public class Location {

	private String locNo;
	private String city;
	
	public Location() {
	}

	public Location(String locNo, String city) {
		super();
		this.locNo = locNo;
		this.city = city;
	}

	public String getLocNo() {
		return locNo;
	}

	public void setLocNo(String locNo) {
		this.locNo = locNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Location [locNo=" + locNo + ", city=" + city + "]";
	}
}
