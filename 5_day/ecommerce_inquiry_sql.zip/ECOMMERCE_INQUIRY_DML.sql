INSERT INTO MSA_CUSTOMER_CQRS(USERID, PWD, NAME, EMAIL)
VALUES('1111', '1234', '홍길동', 'hong@korea.com'); 

insert into MSA_ORDER_CQRS ( orderId, userId, name,  productId, quantity, unitPrice, totalPrice) 
        values ('A1111', '1111', '홍길동','CATALOG-0001', 10, 500, 5000);
insert into MSA_ORDER_CQRS ( orderId, userId, name, productId, quantity, unitPrice, totalPrice) 
        values ('B1111', '1111', '홍길동','CATALOG-0002', 5, 200, 1000);