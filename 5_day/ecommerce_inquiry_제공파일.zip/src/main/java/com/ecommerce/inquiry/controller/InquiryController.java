package com.ecommerce.inquiry.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.inquiry.domain.entity.Customer;
import com.ecommerce.inquiry.service.InquiryService;

import io.swagger.annotations.ApiOperation;

@RestController
public class InquiryController {

    @Autowired
    private InquiryService inquiryService;
    
    @ApiOperation(value = "고객상세조회", httpMethod = "GET", notes = "고객상세조회")
    @RequestMapping(method = RequestMethod.GET, path = "/detail/rest/customers/{userid}")
    public Customer retrieveCustomerDetail(@PathVariable(name = "userid") String userid) throws Exception{
        return inquiryService.retrieveCustomerDetail(userid);
    }

}
