package com.ecommerce.inquiry.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.inquiry.domain.entity.Customer;
import com.ecommerce.inquiry.domain.entity.Order;
import com.ecommerce.inquiry.domain.repository.InquiryRepository;

@Service("inquiryService")
public class InquiryServiceImpl implements InquiryService {

	@Autowired
	InquiryRepository inquiryRepository;

	@Override
	public Customer retrieveCustomerDetail(String userid) throws Exception {
		
		Customer customer = null;
		/*
		 *  고객 정보와 주문 정보 조회해서 반환코드 구현
		 * 
		 */
		return customer;
	}

	@Override
	public Customer selectCustomerByUserid(String userid) throws Exception {
		return inquiryRepository.selectCustomerByUserid(userid);
	}

	@Override
	public int insertCustomer(Customer customer) throws Exception {
		return inquiryRepository.insertCustomer(customer);
	}

	@Override
	public List<Order> selectOrderByUserId(String userid) throws Exception {
		return inquiryRepository.selectOrderByUserId(userid);
	}

	@Override
	public int insertOrder(Order order) throws Exception {
		return inquiryRepository.insertOrder(order);
	}

}
