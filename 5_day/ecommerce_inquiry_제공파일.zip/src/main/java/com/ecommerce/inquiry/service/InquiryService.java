package com.ecommerce.inquiry.service;

import java.util.List;

import com.ecommerce.inquiry.domain.entity.Customer;
import com.ecommerce.inquiry.domain.entity.Order;

public interface InquiryService {

	public Customer retrieveCustomerDetail(String userid) throws Exception;
	public Customer selectCustomerByUserid(String userid) throws Exception;
	public int insertCustomer(Customer customer) throws Exception;
	public List<Order> selectOrderByUserId(String userid) throws Exception;
	public int insertOrder(Order order) throws Exception;
}
