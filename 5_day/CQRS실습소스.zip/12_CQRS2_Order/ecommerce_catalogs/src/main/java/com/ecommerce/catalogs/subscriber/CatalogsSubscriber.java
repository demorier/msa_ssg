package com.ecommerce.catalogs.subscriber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.ecommerce.catalogs.service.CatalogsService;

@Component
public class CatalogsSubscriber {

	@Autowired
	CatalogsService catalogsService;
	
	 @KafkaListener(topics = "create-order", containerFactory = "orderKafkaListenerContainerFactory")
	    public void pingListener(Order order, Acknowledgment ack) {
	        try {
	            System.out.println("Received Order message: " + order);
	            
	            int cnt = catalogsService.updateQuantity(order);
	            System.out.println(order.getProductId()+" 에 해당하는 상품 갯수가 " + order.getQuantity() +" 만큼 감소되었습니다.");
	            ack.acknowledge();
	        } catch (Exception e) {
	        	String msg = "주문 정보에 따른 quantity 수정에 문제가 발생했습니다";
	        	System.out.println("Recieved ping message: " + msg + e);
	        }
	    }
}
