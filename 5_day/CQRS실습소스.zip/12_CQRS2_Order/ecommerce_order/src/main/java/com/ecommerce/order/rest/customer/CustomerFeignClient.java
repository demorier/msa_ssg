package com.ecommerce.order.rest.customer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import feign.hystrix.FallbackFactory;


@FeignClient(name="ecommerce-customer",
		     //url = "http://localhost:8076/ecommerce/customer",
		     fallbackFactory = CustomerFeignClientFallbackFactory.class
		    )
public interface CustomerFeignClient {
	@GetMapping("/ecommerce/customer/rest/customers/{userid}")
	public Customer retrieveCustomer(@PathVariable String userid)throws Exception;
}

@Component
class CustomerFeignClientFallbackFactory implements FallbackFactory<CustomerFeignClient>{
	@Override
	public CustomerFeignClient create(Throwable cause) {
		return new CustomerFeignClient() {
			private final Logger LOGGER = LoggerFactory.getLogger(CustomerFeignClient.class);
			@Override
			public Customer retrieveCustomer(String userid) throws Exception {
				String msg = "feignClient를 이용한 Customer 서비스 호출에 문제가 있습니다.";
				LOGGER.info(msg, cause);
				//return new Customer();  // 
				throw new Exception(msg);
			}
		};
	}
}
