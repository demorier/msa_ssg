package com.ecommerce.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.order.domain.entity.Order;
import com.ecommerce.order.domain.repository.OrderRepository;
import com.ecommerce.order.publisher.OrderPublisher;
import com.ecommerce.order.rest.customer.Customer;
import com.ecommerce.order.rest.customer.CustomerComposite;
import com.ecommerce.order.rest.customer.CustomerFeignClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("orderService")
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	CustomerComposite customerComposite;
	@Autowired
	CustomerFeignClient customerFeignClient;
	
	@Autowired
	OrderPublisher orderPublisher;

	//RestTemplate
		@Override
		public int insertOrder(Order order) throws Exception {
			Customer customer = customerComposite.retrieveCustomer(order.getUserId());
			order.setName(customer.getName());

			///// Kafka 연동////////////
			orderPublisher.insertOrder(order);
			///////////////////////////////////
			return orderRepository.insertOrder(order);
		}
		
		
	//Feign Client + Hystrix
	@Override
	public int insertOrderFeignClient(Order order) throws Exception {
		Customer customer = customerFeignClient.retrieveCustomer(order.getUserId());
		order.setName(customer.getName());
		System.out.println("Customer Feign Client >>" + customer);
		
		return orderRepository.insertOrder(order);
	}

	
	
	@Override
	public List<Order> selectOrderByUserId(String userid) throws Exception {
		return orderRepository.selectOrderByUserId(userid);
	}


}

