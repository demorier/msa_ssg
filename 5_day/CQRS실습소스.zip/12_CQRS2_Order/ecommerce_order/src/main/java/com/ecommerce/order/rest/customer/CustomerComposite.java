package com.ecommerce.order.rest.customer;


public interface CustomerComposite {

	public Customer retrieveCustomer(String userid) throws Exception;
}
