package com.ecommerce.order.rest.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.order.domain.entity.Order;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@Component
public class CustomerCompositeImpl implements CustomerComposite {

	@Value("${customer.api.url}")
	private String CUSTOMER_API_URL;
	
	@LoadBalanced
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	@HystrixCommand(fallbackMethod = "getCustomerFallback", commandKey = "retrieveCustomer")
	public Customer retrieveCustomer(String userid) throws Exception {
		return restTemplate.getForObject(CUSTOMER_API_URL+"/rest/customers/"+userid,
				Customer.class);
	}
	
	public Customer getCustomerFallback(String userid)throws Exception {
		String mesg = "Error: " + userid + "에 해당하는 고객 정보 조회가 지연되고 있습니다.";
		System.out.println(mesg);
		throw new Exception();
	}
	
	public Customer retrieveCustomer2(String userid) throws Exception {
		return restTemplate.exchange(CUSTOMER_API_URL+"/rest/customers/"+userid,
				HttpMethod.GET, null, 
				new ParameterizedTypeReference<Customer>() {
		}).getBody();
	}
	

}
