package com.ecommerce.apicomposite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceApicompositeApplicationTests {

	@Test
	void contextLoads() {
	}

}
