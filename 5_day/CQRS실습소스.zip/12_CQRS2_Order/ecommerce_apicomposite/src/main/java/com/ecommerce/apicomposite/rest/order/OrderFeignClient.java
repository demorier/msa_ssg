package com.ecommerce.apicomposite.rest.order;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import feign.hystrix.FallbackFactory;


@FeignClient(name="ecommerce-order",
		     fallbackFactory = OrderFeignClientFallbackFactory.class
		    )
public interface OrderFeignClient {
	@GetMapping("/ecommerce/order/rest/orders/{userid}")
	public List<Order> retrieveCustomer(@PathVariable String userid)throws Exception;
}

@Component
class OrderFeignClientFallbackFactory implements FallbackFactory<OrderFeignClient>{
	@Override
	public OrderFeignClient create(Throwable cause) {
		return new OrderFeignClient() {
			private final Logger LOGGER = LoggerFactory.getLogger(OrderFeignClient.class);
			@Override
			public List<Order> retrieveCustomer(String userid) throws Exception {
				String msg = "feignClient를 이용한 Order 서비스 호출에 문제가 있습니다.";
				LOGGER.info(msg, cause);
				throw new Exception(msg);
			}
		};
	}
}
