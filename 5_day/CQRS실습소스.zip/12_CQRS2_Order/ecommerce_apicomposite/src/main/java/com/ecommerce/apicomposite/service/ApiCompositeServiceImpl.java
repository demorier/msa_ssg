package com.ecommerce.apicomposite.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.apicomposite.rest.customer.Customer;
import com.ecommerce.apicomposite.rest.customer.CustomerFeignClient;
import com.ecommerce.apicomposite.rest.order.Order;
import com.ecommerce.apicomposite.rest.order.OrderFeignClient;


@Service("apiCompositeService")
public class ApiCompositeServiceImpl implements ApiCompositeService {

    @Autowired
    OrderFeignClient orderFeignClient;
    
    @Autowired
    CustomerFeignClient customerFeiginClient;
    
	@Override
	public Customer retrieveCustomerDetail(String userid) throws Exception {
		
		//1. 고객 기본 정보
		Customer customer = customerFeiginClient.selectCustomerByUserid(userid);
		//2. 고객 주문 정보
		List<Order> orderList = orderFeignClient.retrieveCustomer(userid);
		customer.setOrderList(orderList);
		
		return customer;
	}
}
