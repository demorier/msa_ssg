package com.ecommerce.apicomposite.service;

import com.ecommerce.apicomposite.rest.customer.Customer;

public interface ApiCompositeService {
	public Customer retrieveCustomerDetail(String cstmId) throws Exception;
}
