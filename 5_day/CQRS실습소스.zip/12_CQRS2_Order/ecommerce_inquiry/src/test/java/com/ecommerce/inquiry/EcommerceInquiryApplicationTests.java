package com.ecommerce.inquiry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceInquiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
