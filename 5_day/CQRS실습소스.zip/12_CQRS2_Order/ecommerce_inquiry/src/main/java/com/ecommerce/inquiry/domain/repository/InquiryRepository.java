package com.ecommerce.inquiry.domain.repository;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ecommerce.inquiry.domain.entity.Customer;
import com.ecommerce.inquiry.domain.entity.Order;

@Mapper
public interface InquiryRepository {
	
	public Customer selectCustomerByUserid(String userid) throws Exception;
	public int insertCustomer(Customer customer) throws Exception;
	public List<Order> selectOrderByUserId(String userid) throws Exception;
	public int insertOrder(Order order) throws Exception;
}
