package com.ecommerce.inquiry.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.inquiry.domain.entity.Customer;
import com.ecommerce.inquiry.domain.entity.Order;
import com.ecommerce.inquiry.domain.repository.InquiryRepository;

@Service("inquiryService")
public class InquiryServiceImpl implements InquiryService {

	@Autowired
	InquiryRepository inquiryRepository;

	@Override
	public Customer retrieveCustomerDetail(String userid) throws Exception {
		
		// 1. 고객 기본 정보
		Customer customer = inquiryRepository.selectCustomerByUserid(userid);
		// 2. 고객 주문 정보
		List<Order> orderList = inquiryRepository.selectOrderByUserId(userid);
		customer.setOrderList(orderList);

		return customer;
	}

	@Override
	public Customer selectCustomerByUserid(String userid) throws Exception {
		return inquiryRepository.selectCustomerByUserid(userid);
	}

	@Override
	public int insertCustomer(Customer customer) throws Exception {
		return inquiryRepository.insertCustomer(customer);
	}

	@Override
	public List<Order> selectOrderByUserId(String userid) throws Exception {
		return inquiryRepository.selectOrderByUserId(userid);
	}

	@Override
	public int insertOrder(Order order) throws Exception {
		return inquiryRepository.insertOrder(order);
	}

}
