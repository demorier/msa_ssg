package com.kafka.subscriber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaMsaSubscriberApplicationTests {

	@Test
	void contextLoads() {
	}

}
