package com.kafka.subscriber.subscriber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.kafka.subscriber.domain.entity.Ping;
import com.kafka.subscriber.service.KafkaSubscriberService;

@Component
public class PingSubscriber {

	@Autowired
	KafkaSubscriberService  service;
	
	 @KafkaListener(topics = "${ping.topic.name}", containerFactory = "pingKafkaListenerContainerFactory")
	    public void pingListener(Ping ping, Acknowledgment ack) {
	        try {
	            System.out.println("Received ping message: " + ping);
	            System.out.println("필요시 서비스 호출: " + service.working());
	            
	            ack.acknowledge();
	        } catch (Exception e) {
	        	String msg = "시스템에 예상치 못한 문제가 발생했습니다";
	        	System.out.println("Recieved ping message: " + msg + e);
	        }
	    }
}
