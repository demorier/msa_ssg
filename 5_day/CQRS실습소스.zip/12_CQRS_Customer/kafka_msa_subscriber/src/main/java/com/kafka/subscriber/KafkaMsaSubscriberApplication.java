package com.kafka.subscriber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaMsaSubscriberApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaMsaSubscriberApplication.class, args);
	}

}
