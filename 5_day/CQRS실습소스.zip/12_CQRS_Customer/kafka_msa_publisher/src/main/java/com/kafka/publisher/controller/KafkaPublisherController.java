package com.kafka.publisher.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.publisher.domain.entity.Ping;
import com.kafka.publisher.domain.entity.Pong;
import com.kafka.publisher.service.PingService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/kafka")
public class KafkaPublisherController {

    @Autowired
    PingService pingService;

    @ApiOperation(value = "Kafka publisher", httpMethod = "POST", notes = "Kafka publisher")
    @RequestMapping(value = "/publish", method=RequestMethod.POST)
    public Pong pingAndPong(@RequestBody final Ping ping) throws Exception {
        return pingService.pingAndPong(ping);
    }
}