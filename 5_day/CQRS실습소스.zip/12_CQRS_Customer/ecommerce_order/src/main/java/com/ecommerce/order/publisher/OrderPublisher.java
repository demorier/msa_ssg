package com.ecommerce.order.publisher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import com.ecommerce.order.domain.entity.Order;

@Component
public class OrderPublisher {

	@Autowired
    private KafkaTemplate<String, Order> orderKafkaTemplate;
	
	public void insertOrder(Order order) {
		ListenableFuture<SendResult<String, Order>> future = orderKafkaTemplate.send("msa", order);
		
		future.addCallback(new ListenableFutureCallback<SendResult<String, Order>>() {
            @Override
            public void onSuccess(SendResult<String, Order> result) {
            	Order order = result.getProducerRecord().value();
                System.out.println("Sent message=[" + order.toString() + "] with offset=[" + result.getRecordMetadata().offset() + "]");
            }

            @Override
            public void onFailure(Throwable ex) {
                System.out.println( "Unable to send message=[" + order.toString() + "] due to : " + ex.getMessage());
            }
        });
	}
}
