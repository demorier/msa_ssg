package com.ecommerce.inquiry.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.ecommerce.inquiry.domain.entity.Customer;



//@EnableKafka
@Configuration
public class KafkaSubscriberConfig {

	public ConsumerFactory<String, Customer> customerConsumerFactory() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, "pong");  // Consumer를 식별하는 고유 아이디.
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class); 
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");  // offset을 주기적으로 commit 할지 여부
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest"); // earliest: 맨 처음부터 다시 , latest: 이전꺼 무시 새로입력 데이터부터 읽기 시작 
		return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(),
				new JsonDeserializer<>(Customer.class, false));
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, Customer> customerKafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, Customer> factory = new ConcurrentKafkaListenerContainerFactory<>();
		//ENABLE_AUTO_COMMIT_CONFIG= false로 지정했을때, 어떻게 commit할지를 지정한다.
		factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE); // 즉각적으로 ack 요청한다.
		factory.setConsumerFactory(customerConsumerFactory());
		return factory;
	}
}