package com.ecommerce.order.rest.customer;
/*
 * @FeignClient("stores")
public interface StoreClient {
    @RequestMapping(method = RequestMethod.GET, value = "/stores")
    List<Store> getStores();
 * 
 */

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
//http://localhost:8076/ecommerce/customer/rest/customers/아이디값

import feign.hystrix.FallbackFactory;
@FeignClient(name="ecommerce-customer",
            url="http://localhost:8076/ecommerce/customer", //나중에 Eureka 사용해서 url 지움
            fallbackFactory = CustomerFeignClientFallbackFactory.class)
public interface CustomerFeignClient {
	 @RequestMapping("/rest/customers/{userid}")
	 public Customer retrieveCustomer(@PathVariable String userid) throws Exception;
}

@Component
class CustomerFeignClientFallbackFactory implements FallbackFactory<CustomerFeignClient>{
	@Override
	public CustomerFeignClient create(Throwable cause) {
		return new CustomerFeignClient() {
		@Override
			public Customer retrieveCustomer(String userid) throws Exception {
			String mesg = "Error: " + userid + "에 해당하는 고객 정보 조회가 지연되고 있습니다.";
				System.out.println(mesg);
				//return new Customer();  // 
				throw new Exception(mesg);
			}
		};
	}
}