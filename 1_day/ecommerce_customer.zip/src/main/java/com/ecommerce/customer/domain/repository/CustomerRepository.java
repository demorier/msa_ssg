package com.ecommerce.customer.domain.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ecommerce.customer.domain.entity.Customer;

@Mapper
public interface CustomerRepository {

	public List<Customer> selectAllCustomer() throws Exception;
}
