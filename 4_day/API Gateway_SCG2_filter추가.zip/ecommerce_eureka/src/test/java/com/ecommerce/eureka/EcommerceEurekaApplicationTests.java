package com.ecommerce.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
