package com.ecommerce.order.publisher;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.ecommerce.order.domain.entity.Order;

@Component
public class OrderPublisher {

	@Autowired
    private KafkaTemplate<String, Order> pingKafkaTemplate;

    @Value(value = "${ping.topic.name}")
    private String pingTopicName;
    
    public Order insertOrder(Order ping) throws Exception {
    	//pingKafkaTemplate.send(pingTopicName, ping);  만 있어도 가능
    	ListenableFuture<SendResult<String, Order>> future = pingKafkaTemplate.send(pingTopicName, ping);

    	////////////////////////////////////////////////////////////////////////
    	ProducerRecord<String, Order> producerRecord= future.get().getProducerRecord();
    	System.out.println("ProducerRecord 의 key: " +  producerRecord.key() );
    	System.out.println("ProducerRecord 의 value: " +  producerRecord.value() );
    	System.out.println("ProducerRecord 의 topic: " +  producerRecord.topic() );
    	System.out.println("ProducerRecord 의 partition: " +  producerRecord.partition() );
    	System.out.println("ProducerRecord 의 timestamp: " +  producerRecord.timestamp() );
    	System.out.println("ProducerRecord 의 headers: " +  producerRecord.headers());
    	////////////////////////////////////////////////////////////////////////
        future.addCallback(new ListenableFutureCallback<SendResult<String, Order>>() {
            @Override
            public void onSuccess(SendResult<String, Order> result) {
            	Order g = result.getProducerRecord().value();
                System.out.println("Sent message=[" + g.toString() + "] with offset=[" + result.getRecordMetadata().offset() + "]");
            }

            @Override
            public void onFailure(Throwable ex) {
                System.out.println( "Unable to send message=[" + ping.toString() + "] due to : " + ex.getMessage());
            }
        });
        return ping;
    }
}
