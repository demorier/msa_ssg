package com.ecommerce.order.rest.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class CustomerCompositeImpl implements CustomerComposite {

	@Value("${customer.api.url}")
	String CUSTOMER_API_URL;
	
	//RestTemplate 사용
	//////////////////////////////////////////////
	@LoadBalanced
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	RestTemplate restTemplate;
	//////////////////////////////////////////////
	
	@Override
	@HystrixCommand(fallbackMethod = "getCustomerFallback", commandKey = "retrieveCustomer")
	public Customer retrieveCustomer(String userid) throws Exception {
		String url = CUSTOMER_API_URL+"/rest/customers/"+userid;
		Customer c = restTemplate.getForObject(url, Customer.class);
		return c;
	}
	public Customer getCustomerFallback(String userid)throws Exception {
		String mesg = "Error: " + userid + "에 해당하는 고객 정보 조회가 지연되고 있습니다.";
		System.out.println(mesg);
		throw new Exception();
	}

}
