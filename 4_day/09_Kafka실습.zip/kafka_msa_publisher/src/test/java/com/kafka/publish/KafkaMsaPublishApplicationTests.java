package com.kafka.publish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaMsaPublishApplicationTests {

	@Test
	void contextLoads() {
	}

}
