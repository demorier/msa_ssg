package com.kafka.publisher.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kafka.publisher.domain.entity.Ping;
import com.kafka.publisher.domain.entity.Pong;
import com.kafka.publisher.publisher.PingPublisher;

@Service
public class PingService{
	
	@Autowired
	PingPublisher pingPublisher;
	
    public Pong pingAndPong(Ping ping) throws Exception {
    	return pingPublisher.pingAndPong(ping);
    }
}

