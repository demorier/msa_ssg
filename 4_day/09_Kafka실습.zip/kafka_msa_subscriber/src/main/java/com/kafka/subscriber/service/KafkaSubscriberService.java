package com.kafka.subscriber.service;


import org.springframework.stereotype.Component;

@Component
public class KafkaSubscriberService {
 
	public String working() {
		return "KafkaSubscriberService.working";
	}
}
